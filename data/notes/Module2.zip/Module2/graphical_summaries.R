####################################################################
## Graphical summaries of data
####################################################################

status = c("freshman", "freshman", "sophomore", "sophomore", "junior", "sophomore")

#################################################
# frequency table and relative frequency tables #
# when there are NO missing values
#################################################
table(status) # frequency table
table(status) / length(status) #relative frequency (proportions) 

##################################################################
# pie charts show a slice of pie proportional to each frequency
##################################################################
pie(table(status))

##################################################################
# bar graphs construct bars whose heights correspond to 
# frequencies or relative frequencies
##################################################################
t = table(status)
barplot(t)
barplot(t/sum(t), main = "Class status", ylab = "relative frequency", 
        col = "blue", axis.lty = 1)

##################################################################
# Construct a Pareto chart to show bars from tallest to shortest 
##################################################################
o = order(t, decreasing = TRUE)
barplot(t[o]/sum(t), main = "Class status", ylab = "relative frequency", 
        col = "blue", axis.lty = 1)

##################################################################
# Let's look at the survey data (from a prior class)
# that we analyzed previously
##################################################################

survey = read.delim("http://pastebin.com/raw/1csmBawE")

###################################################################         
# 1. Construct a relative frequency table for the number of males
#     and females
# 2. Construct a bar graph for the proportion of individuals that 
#    agree or disagree that same-sex marriage should be legal in
#    all 50 states. The title of the chart should be "Should same
#     sex marriage be legal in all 50 states?"
###################################################################


#################################################
# frequency and relative frequency tables
# with missing values
#################################################

status = c("freshman", "freshman", "sophomore", "sophomore", NA, "sophomore")
table(status) # frequency table, missing values are automatically removed

table(status) / length(status) ## relative frequency table -- INCORRECT!

## relative frequencies should be based on non-missing values only ##
table(status) / sum(!is.na(status))


#########################################################
# Histograms are like bar graphs for quantitative values
# The height of the bar corresponds to the number 
# or proportion of observations that fall within
# a range of values
###################################################
hist(survey$FB)

###########################################################
# histogram shapes
# unimodal = 1 mound or mode
# bimodal = 2 mounds or modes
# skewed left: tail is longer (or fatter) on the left
# symmetric: tails are approximately the same length
# skewed right: tail is longer (or fatter) on the right
###########################################################

x.norm = rnorm(500)
x.right = c(x.norm, runif(10,3,10))
x.left = c(x.norm, runif(10,-10,-3))
par(mfrow = c(1,3))
hist(x.left, main = "left-skewed")
hist(x.norm, main = "symmetric")
hist(x.right, main = "right-skewed")

par(mfrow = c(1,1))  # reset display for 1 image
bimodal = c(rnorm(500, mean = 70), rnorm(500, mean = 65))
hist(bimodal, main = "bimodal distribution")
