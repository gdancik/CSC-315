####################################################################
## Percentiles and Boxplots
####################################################################

percentile <- function(x, val) {
   x = x[!is.na(x)]  ## remove missing values
   ans = sum(x <= val) / length(x) * 100
   return(ans)
}

x = 1:10

############################################
# What is the percentile of the value 6.5?
############################################
percentile(x,6.5)

############################################
# Visualization of the 60th percentile
############################################
color = rep("black", length(x))
color[x <=6.5] = "red"
y = rep(1,length(x))
plot(x, y, pch = 18, col = color)
abline(v = 6.5)
text(3, 1.3, "60%", col = "red")
text(9, 1.3, "40%")

#############################################
# find the 20th and 30th percentiles
#############################################
quantile(x, .2)   ## finds the 20th percentile
quantile(x, .3)   ## finds the 30th percentile
quantile(x, c(.2,.3)) ## finds both the 20th and 30th percentile

#############################################
# Quartiles and 5-number summary 
# (min, Q1, Q2, Q3, max)
# summary/quantile and fivenum give different
# values of Q1 and Q3 when there are even 
# numbers of observations
# However both are correct
#############################################

summary(x) ## note that this also contains the mean
quantile(x) ## just the quantiles
fivenum(x)  ## five number summary

#############################################
# Quartiles are the same for odd number of
# observations
#############################################
z = 1:11
summary(z)
quantile(z)
fivenum(z)

#############################################
# boxplot - draw box around Q1 and Q3
# draw fence corresonding to Q1 - 1.5*IQR
# and Q3 + 1.5*IQR
#############################################
boxplot(x)
boxplot(x, horizontal = TRUE)

# Let's compare the heights of males and females using side-by-side boxplots #
# males = 0, females = 1
heights = read.csv("http://pastebin.com/raw/g7UdTFKG")

