##############################################
# associations.R: 
##############################################

## Manually construct contingency table from pg 7 of the notes ##
pesticides = cbind(Present = c(29,19485), "Not Present" = c(98, 7086))
rownames(pesticides) = c("Organic", "Conventional")
pesticides

## confirm row and column sums ##
colSums(pesticides)
rowSums(pesticides)

## conditional proportions: conditional on type (organic or conventional)
## Note: For matrix 'm' and vector 'v', m / v will divide m[i,] / v[i] for all i
pesticides.conditional = pesticides / rowSums(pesticides)
pesticides.conditional

## construct barplot; note that we use transpose function t() to switch
## rows and columns; this is because barplot function plots by column
barplot(t(pesticides.conditional), beside = TRUE, 
        legend.text = colnames(pesticides.conditional), 
        col = c("darkred", "lightblue"), main = "Pesticide Status",
        ylab = "proportion")

## bars are 'stacked' (i.e., beside = FALSE) by default
barplot(t(pesticides.conditional), 
        legend.text = colnames(pesticides.conditional), 
        col = c("darkred", "lightblue"), main = "Pesticide Status",
        ylab = "proportion", args.legend = list(x = "topleft"))


#################################################################
### example of no relationship; remember we must compare 
### conditional proportions between each EXPLANATORY variable and 
### not each response variable
#################################################################
p2 = cbind(Present = c(0.6,0.62), "Not Present" = c(0.4, 0.38))
rownames(p2) = c("Organic", "Conventional")
p2

## construct barplot; don't forget to use transpose if necessary! ##
barplot(t(p2), legend.text = colnames(p2), 
          col = c("darkred", "lightblue"), main = "Pesticide Status",
          ylab = "proportion")
    
## import our survey data ##
survey = read.delim("http://pastebin.com/raw/QDSga7qF")

## is their a relationship between cat/dog person and favorite programming language
## creates contingency table; first vector gives rows; 2nd gives columns
t = table(survey$CatOrDog, survey$Programming)
t.conditional = t / rowSums(t)
barplot(t(t.conditional), col = 2:4, 
        main = "What is your favorite programming language?",
        xlab = "Cat or Dog Preference", ylab = "proportion", 
        legend.text = colnames(t.conditional))

