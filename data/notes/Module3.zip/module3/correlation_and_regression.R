#########################################
# Correlation and regression
#########################################
#######################################
## load internet data
#######################################

internet = read.delim("http://pastebin.com/raw/enxWu6R6")

fb.penetration = internet$Facebook.Penetration..Percent.
internet.penetration = internet$Internet.Penetration..Percent.

##############################################
# what is the mean value of internet and
# fb penetration?
##############################################

##############################################
# describe the shape of the distributions for
# internet penetration.
##############################################

##################################################
# scatterplots: plots a point for each pair of 
#   (x,y) values
##################################################
plot(internet.penetration, fb.penetration, 
     xlab = "Internet Penetration (%)", ylab = "FB Penetration (%)", 
     main = "Internet and FB penetration rates")

## replot with closed circles by setting pch (plotting character)
plot(internet.penetration, fb.penetration, 
     xlab = "Internet Penetration (%)", ylab = "FB Penetration (%)", 
     main = "Internet and FB penetration rates", pch = 19)

## where is the United States?
col = rep("black", length(internet.penetration))
col[internet$Country == "USA"] = "red"
## replot with new color highlighting the US
plot(internet.penetration, fb.penetration, 
     xlab = "Internet Penetration (%)", ylab = "FB Penetration (%)", 
     main = "Internet and FB penetration rates", pch = 19, col = col)

########################################################################
## Is there a trend in the data?
## what countries are potential outliers (from the trend in the data)
########################################################################

## Let's highlight the outlier
## Note: for logical comparison, use single & or | (NOT && or ||)
index = fb.penetration < 10 & internet.penetration>60
internet$Country[index]

#######################################################################
# example correlations
#######################################################################
plot.cor <-function(x,y, location = "topleft", ...) {
  plot(x,y, ...)
  abline(h = mean(y), col = "red")
  abline(v = mean(x), col = "red")
  l = lm(y~x)
  abline(l, col = "blue")
  r = cor(x,y)
  r = paste("r = ", round(r,2))
  legend(x = location,r)
}


#######################################################################
# generate data
#######################################################################
x = rnorm(100)
y1 = rnorm(100, mean = x, sd = .4)
y2 = rnorm(100, mean = -x, sd = .4)
y3 = rnorm(100, mean = x, sd = 2)
y4 = rnorm(100, mean = -x, sd = 2)
y5 = rnorm(100)

#######################################################################
# plot data along with correlations
#######################################################################
par(mfrow = c(3,2))
par(mar = c(2,2,2,2)+.1)
plot.cor(x,y1)
plot.cor(x,y2, location = "topright")
plot.cor(x,y3)
plot.cor(x,y4, location = "topright")
plot.cor(x,y5)
plot.cor(x, x**2)


### reset to 1 panel for plotting (not necessary on console)
par(mfrow = c(1,1))

#############################################
# find correlation betweeen internet and FB
# penetration
#############################################
plot(internet.penetration, fb.penetration, 
         xlab = "Internet Penetration (%)", ylab = "FB Penetration (%)", 
        main = "Internet and FB penetration rates", pch = 19)

## to get correlation ##
cor(internet.penetration, fb.penetration)

#############################################
# linear regression
#############################################

###################################################################
## fit a linear regression line with internet penetration as the
## explanatory or independent variable (x) and FB penetration as
## the response variable (y)
###################################################################

###############################################################################
## Questions: Find and interpret tye y-intercept of the linear regression line
##            Find and interpret the slope
################################################################################# get predicted values for each observation ##

fit = lm(fb.penetration ~ internet.penetration)

## display results ##
fit

## display summary of results (more information) ##
summary(fit)

## add regression line to current plot ##
abline(fit, col = "red")

# predicted fb.penetration for all countries
predict(fit)

## what is the predicted FB penetration rate for a country that
## has 50% internet penetration
predict(fit, data.frame(internet.penetration=50))

## what is the predicted FB penetration rate for countries that
## have 50% and 80% internet penetrations
predict(fit, data.frame(internet.penetration=c(50,80)))


####################################################
# View the residuals - the linear regression line
# is the line that minimizes the sum of the 
# squared residuals
####################################################
plot.resids <- function(x,y, ...) {
  plot(x,y, pch = 19,...)
  l = lm(y~x)
  abline(l, col = "red")
  points(x, predict(l), pch = 19, col = "red")
  segments(x,predict(l), x, y, col = "blue")
  legend("topleft", c("obs", "prediction", "residual"), 
         lty = c(0,0,1), pch = c(19,19,-1),col = c("black", "red", "blue"))
}

plot.resids(internet.penetration, fb.penetration)

####################################################
## alternative format to fit linear model
## necessary for new predictions when getting
## variables directly from a data.frame
####################################################

internet.table = data.frame(internet = internet.penetration, fb = fb.penetration)
fit = lm(internet ~ fb, data = internet.table)
predict(fit, data.frame(fb = .5))


######################################################
# Find the regression for the ANNUAL temp against YEAR 
# 1. Find and interpret the slope
# 2. Find and interpret the y-int
# 3. Predict average temp in the year 1999
# 4. Predict average temp in the year 3000
######################################################

temps = read.delim("http://pastebin.com/raw/KZgkViBK")
